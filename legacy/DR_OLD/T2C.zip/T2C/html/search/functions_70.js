var searchData=
[
  ['pvupdated',['PVupdated',['../class_t2_c_manager.html#a011afb3a91c2dc08f052f65204dcf24d',1,'T2CManager']]]
];
