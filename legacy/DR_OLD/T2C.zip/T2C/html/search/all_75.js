var searchData=
[
  ['unsubscribevalues',['unsubscribeValues',['../class_t2_c_manager.html#abb3969cc1325926859444dad50a3c726',1,'T2CManager']]],
  ['updatevalue',['updateValue',['../class_t2_c_manager.html#a82120e14de0662c77327ef1e89194aa7',1,'T2CManager']]]
];
