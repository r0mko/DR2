var searchData=
[
  ['immediate',['immediate',['../class_t2_c_manager.html#aa9af65c6157ef33db9afd964b5f3b058',1,'T2CManager']]],
  ['itype',['iType',['../struct_p_v.html#a8929ed79170ed8f87817646de10799fe',1,'PV']]]
];
