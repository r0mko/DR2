var searchData=
[
  ['status',['status',['../struct_p_v.html#a02551777c1773cd8d67195be4ba18653',1,'PV']]],
  ['subscribed',['subscribed',['../struct_p_v.html#a865f200b8c4ea2cb89894e7133245bb7',1,'PV']]]
];
