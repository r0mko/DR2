var searchData=
[
  ['hasrawdata',['hasRawData',['../class_t2_c_manager.html#a4bd7aafc050239fcb437eae7a5856bf3',1,'T2CManager']]]
];
