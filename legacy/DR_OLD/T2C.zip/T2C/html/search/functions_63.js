var searchData=
[
  ['canreadline',['canReadLine',['../class_t2_c_manager.html#a4bea191e0ae504c3c84c3576262d8a4f',1,'T2CManager']]],
  ['commit',['commit',['../class_t2_c_manager.html#af60d1c7c4da4e192d91c0fd2c86b852d',1,'T2CManager']]],
  ['connecttot2c',['connectToT2C',['../class_t2_c_manager.html#a6f8148641b9e93f139c7be7545564256',1,'T2CManager::connectToT2C(QHostAddress addr, quint16 port, bool verbose=false)'],['../class_t2_c_manager.html#ae2d1b84a8ce64cd625b377656e787879',1,'T2CManager::connectToT2C(QString addr, quint16 port, bool verbose=false)']]]
];
