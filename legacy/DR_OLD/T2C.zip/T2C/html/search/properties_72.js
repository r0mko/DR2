var searchData=
[
  ['rawmode',['rawMode',['../class_t2_c_manager.html#abb077bec336cee71d08d2a80277a0134',1,'T2CManager']]]
];
