var searchData=
[
  ['immediate',['immediate',['../class_t2_c_manager.html#aa9af65c6157ef33db9afd964b5f3b058',1,'T2CManager']]]
];
