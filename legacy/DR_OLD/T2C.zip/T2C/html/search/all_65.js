var searchData=
[
  ['encoding',['encoding',['../class_t2_c_manager.html#a5905cc8bc0534c5996b6d8b8d655f2db',1,'T2CManager']]]
];
